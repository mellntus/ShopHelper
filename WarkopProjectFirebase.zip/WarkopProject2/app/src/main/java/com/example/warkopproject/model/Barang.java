package com.example.warkopproject.model;

import java.io.Serializable;

public class Barang implements Serializable {
    private String namaBarang, kategoriBarang, key;
    private Integer stockBarang;

    public Barang() {
    }

    public Barang(String namaBarang, String kategoriBarang, String key, Integer stockBarang) {
        this.namaBarang = namaBarang;
        this.kategoriBarang = kategoriBarang;
        this.key = key;
        this.stockBarang = stockBarang;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public String getKategoriBarang() {
        return kategoriBarang;
    }

    public void setKategoriBarang(String kategoriBarang) {
        this.kategoriBarang = kategoriBarang;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Integer getStockBarang() {
        return stockBarang;
    }

    public void setStockBarang(Integer stockBarang) {
        this.stockBarang = stockBarang;
    }
}
