package com.example.warkopproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.warkopproject.databinding.ActivityMainBinding;
import com.example.warkopproject.page.history.HistoryFragment;
import com.example.warkopproject.page.home.HomeFragment;
import com.example.warkopproject.page.listMenu.ListFragment;
import com.example.warkopproject.page.profile.ProfileFragment;
import com.example.warkopproject.page.stock.StockFragment;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.fragment_container, new HomeFragment());
        ft.commit();

        listener();

        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

    }


    private void listener(){
        /*
        binding.navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()) {
                    case R.id.nav_logout:
                        //LOGOUT HERE
                        MainActivity.this.finish();
                        break;

                }
                return true;
            }
        });*/

        binding.bnav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                switch(item.getItemId()){
                    case R.id.m_home:
                        ft.replace(R.id.fragment_container, new HomeFragment());
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case R.id.m_menu:
                        ft.replace(R.id.fragment_container, new StockFragment());
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case R.id.m_order:
                        ft.replace(R.id.fragment_container, new ListFragment());
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case R.id.m_history:
                        ft.replace(R.id.fragment_container, new HistoryFragment());
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case R.id.m_profile:
                        ft.replace(R.id.fragment_container, new ProfileFragment());
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                }

                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                binding.drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}